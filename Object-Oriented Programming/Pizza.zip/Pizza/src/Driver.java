import java.text.NumberFormat;

public class Driver {
	public static void main(String[] args) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		Pizza p1 = new Pizza(1,1,2,3);
		System.out.println(p1.getDescription());
		System.out.println("Cost for p1: " + nf.format(p1.calcCost()));
	}
}
